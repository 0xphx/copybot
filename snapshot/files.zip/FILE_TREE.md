# 📂 VOLLSTÄNDIGER DATEIPFAD & ÜBERSICHT

## 🗂️ Projekt Root
```
C:\Users\phili\Documents\GitHub\copybot\bot\
```

---

## 📁 Vollständige Dateistruktur

```
C:\Users\phili\Documents\GitHub\copybot\bot\
│
├── main.py                                    # ✅ Entry Point
│
├── config/
│   └── network.py                             # ✅ RPC URLs (Helius)
│
├── observation/
│   ├── __init__.py
│   ├── models.py                              # ✅ TradeEvent
│   ├── observer.py                            # ✅ TradeObserver
│   └── sources/
│       ├── __init__.py
│       ├── base.py                            # ✅ Abstract TradeSource
│       ├── fake.py                            # Fake Trade Generator
│       ├── solana_polling.py                  # ✅ HTTP Polling (WORKS!)
│       ├── solana_rpc.py                      # WebSocket (deprecated)
│       └── hybrid.py                          # ✅ Mainnet + Fake
│
├── pattern/
│   ├── __init__.py                            # ✅ NEU
│   └── redundancy.py                          # ✅ Pattern Detection
│
├── wallets/
│   ├── __init__.py
│   ├── models.py                              # ActiveWallet Model
│   ├── repository.py                          # load_active_wallets()
│   └── sync.py                                # sync_wallets()
│
├── data/
│   ├── axiom.db                               # SQLite Database
│   └── axiom_wallets.json                     # Wallet Import JSON
│
├── runners/
│   ├── __init__.py
│   ├── import_axiom.py                        # Wallet Import
│   ├── test_wallet_sync.py                   # Test Wallets
│   ├── offline.py                             # Offline Simulator
│   ├── live_polling.py                        # ✅ Production (WORKS!)
│   ├── hybrid.py                              # ✅ Testing Mode (WORKS!)
│   ├── live_rpc.py                            # WebSocket (deprecated)
│   ├── test_network.py                        # Network Test
│   └── scann_all.py                           # Scan All Transactions
│
├── network_debug.py                           # Network Diagnostics
├── simple_network_test.py                     # Simple Network Test
└── network_report.txt                         # Last Network Report
```

---

## 🔑 Wichtigste Dateien für Migration

### 1. Core Logic
```
observation/sources/solana_polling.py          # HTTP Polling Source
pattern/redundancy.py                          # Pattern Detection Engine
observation/sources/hybrid.py                  # Hybrid Mode
```

### 2. Configuration
```
config/network.py                              # RPC URLs + API Key
data/axiom_wallets.json                        # Wallet List
```

### 3. Runners
```
runners/live_polling.py                        # Production
runners/hybrid.py                              # Testing
```

### 4. Models
```
observation/models.py                          # TradeEvent
wallets/models.py                              # ActiveWallet
```

---

## 📝 Dateien die du mitnehmen solltest:

### Must-Have:
1. `config/network.py` - Helius API Key
2. `data/axiom_wallets.json` - Deine Wallets
3. `observation/sources/solana_polling.py` - Polling Source
4. `pattern/redundancy.py` - Redundancy Engine
5. `observation/sources/hybrid.py` - Hybrid Source
6. `runners/live_polling.py` - Production Runner
7. `runners/hybrid.py` - Testing Runner

### Nice-to-Have:
8. `observation/models.py` - TradeEvent Model
9. `wallets/sync.py` - Wallet Sync Logic
10. `main.py` - Entry Point

---

## 🔄 Quick Migration Guide

### Schritt 1: Neuer Chat - Kontext geben
```
"Ich habe einen Solana Copy Trading Bot gebaut.
Hier ist der vollständige Snapshot: [PROJECT_SNAPSHOT.md]

Aktueller Status:
- Polling funktioniert
- Redundancy Engine funktioniert
- Hybrid Mode funktioniert

Ich möchte weitermachen mit: [DEIN ZIEL]"
```

### Schritt 2: Wichtige Infos bereitstellen
- Project Snapshot (diese Datei)
- Helius API Key
- Wallet Liste
- Aktuelles Problem/Ziel

### Schritt 3: Code-Dateien falls benötigt
Falls Claude Code braucht:
```
"Hier ist die Datei [NAME]:
[INHALT kopieren]"
```

---

## 💾 Backup Commands

### Projekt komplett sichern:
```powershell
# Alle Python Files
Get-ChildItem -Path . -Recurse -Filter *.py | ForEach-Object { $_.FullName }

# Alle wichtigen Configs
Get-ChildItem -Path .\config, .\data -Recurse
```

### Einzelne Dateien lesen:
```powershell
Get-Content config\network.py
Get-Content data\axiom_wallets.json
Get-Content pattern\redundancy.py
```

---

## 🎯 Quick Start für neuen Chat

**Minimaler Kontext:**
```
"Ich habe einen Solana Copy Trading Bot:

✅ Was funktioniert:
- HTTP Polling (solana_polling.py)
- Redundancy Engine (redundancy.py)
- Hybrid Testing Mode (hybrid.py)
- Pattern Detection (2+ Wallets kaufen = Signal)

⚙️ Setup:
- Helius RPC (API Key: f607043d-baf5-4bcb-bd7e-c9fca54c5cff)
- 5 Wallets überwacht
- Polling alle 2s

🎯 Nächstes Ziel:
[DEIN ZIEL HIER]

Brauchst du Code-Details?"
```

---

## 📊 Key Metrics

```
Zeilen Code:        ~2,500
Dateien:            ~25
Funktioniert:       Ja ✅
Test Output:        Signals erkannt ✅
Production Ready:   80% (Execution fehlt)
```

---

## 🔗 Links für neuen Chat

Helius Dashboard: https://helius.dev
Projekt Root: C:\Users\phili\Documents\GitHub\copybot\bot\

---

## 🎓 Was du Claude sagen solltest

**Kurz:**
"Ich habe einen Solana Copy Trading Bot mit Polling und Pattern Detection. Alles funktioniert. Hier ist der Snapshot."

**Lang:**
"Ich habe einen Solana Copy Trading Bot gebaut der:
1. Via HTTP Polling Wallet Transactions überwacht
2. Eine Redundancy Engine hat die erkennt wenn 2+ Wallets das gleiche kaufen
3. Einen Hybrid Testing Mode hat (Real + Fake Trades)
4. Mit Helius RPC läuft

Aktueller Status: Pattern Detection funktioniert perfekt.
Nächstes Ziel: [DEIN ZIEL]"

---

**Diese Datei + PROJECT_SNAPSHOT.md = Vollständiger Kontext!** 📦
