# 🤖 New Chat Initialization Prompt

## 📋 Kopiere diesen Prompt in den neuen Chat:

---

**Hallo Claude!**

Ich arbeite an einem Solana Copy Trading Bot im Verzeichnis `C:\Users\phili\Documents\GitHub\copybot\bot`.

## 🔧 Wichtige Einstellungen:

### 1. Dateiberechtigungen
Du hast **VOLLSTÄNDIGE SCHREIBRECHTE** auf alle Dateien in diesem Projekt. 

**KRITISCH - Befolge diese Regeln:**
- ✅ **FÜHRE Änderungen DIREKT aus** - nutze `Filesystem:write_file` für Windows Paths
- ✅ **ÜBERSCHREIBE Dateien** wenn nötig - ich möchte keine Downloads
- ✅ **TESTE deinen Code** wenn möglich vor dem Schreiben
- ❌ **NIEMALS** Dateien zum Download anbieten - schreibe sie direkt!

### 2. Beispiel für korrekte Dateiberarbeitung:

**RICHTIG:**
```
Filesystem:write_file
path: C:/Users/phili/Documents/GitHub/copybot/bot/trading/engine.py
content: [vollständiger Dateiinhalt]
```

**FALSCH:**
```
"Hier ist die aktualisierte Datei zum Download..."
"Ersetze die alte Datei mit dieser neuen..."
```

### 3. Arbeitsweise
Wenn ich dich bitte eine Datei zu ändern:
1. Lese die Datei (falls nötig)
2. Mache die Änderungen
3. **Schreibe die Datei SOFORT zurück**
4. Bestätige kurz was geändert wurde

**KEIN Extra-Schritt für mich!**

---

## 📚 Projekt-Kontext:

### Bisherige Chat-History:
- **Transcript Verzeichnis:** `/mnt/transcripts/`
- **Letzte Session:** `2026-02-24-11-38-42-hybrid-approach-cleanup-fix.txt`
- **Journal:** `/mnt/transcripts/journal.txt`
- **Aktueller Snapshot:** Siehe `CURRENT_CHAT_SNAPSHOT.md` (bereits hochgeladen)

### Projekt-Struktur:
```
C:\Users\phili\Documents\GitHub\copybot\bot\
├── main.py                          # Entry point
├── runners/
│   └── paper_mainnet.py            # Main runner (KÜRZLICH GEÄNDERT)
├── trading/
│   ├── engine.py                   # Trading engine (KÜRZLICH GEÄNDERT)
│   ├── portfolio.py                # Portfolio management
│   ├── price_oracle.py             # Price fetching (KÜRZLICH GEÄNDERT)
│   └── connection_monitor.py       # Health monitoring
├── observation/
│   └── sources/
│       └── solana_polling.py       # Transaction polling
├── pattern/
│   └── redundancy.py               # Signal validation
└── wallets/
    └── sync.py                     # Wallet management
```

### Aktuelle Features:
✅ Interactive Configuration beim Start
✅ Real-time Price Fetching (Jupiter v6 + Birdeye + CoinGecko)
✅ Live Price Updates (konfigurierbar)
✅ Clean Logs im Fast Mode
✅ Visual BUY/SELL Signals
✅ Runtime Tracking
✅ Connection Health Monitoring
✅ Hybrid Approach für Missed SELLs
✅ Emergency Exit bei Network Outage
✅ Adaptive Polling (5s normal / 0.5s fast)

### Zuletzt geänderte Dateien (heute):
1. `bot/trading/price_oracle.py` - Jupiter v6, Birdeye Fallback
2. `bot/trading/engine.py` - Price Monitor Loop, SELL Box
3. `bot/runners/paper_mainnet.py` - Interactive Config, Runtime, Filters

---

## 🎯 Deine Aufgaben:

Wenn ich dich bitte:
- **Code zu ändern** → Lese, ändere, SCHREIBE SOFORT zurück
- **Features hinzuzufügen** → Implementiere und SCHREIBE SOFORT zurück
- **Bugs zu fixen** → Fixe und SCHREIBE SOFORT zurück

**Frage NIEMALS ob du die Datei überschreiben darfst - TU ES EINFACH!**

---

## ✅ Bestätigung

Antworte mit:
```
✅ Verstanden! Ich habe:
- Vollständige Schreibrechte auf C:\Users\phili\Documents\GitHub\copybot\bot
- Werde ALLE Änderungen DIREKT ausführen
- Werde NIEMALS Dateien zum Download anbieten
- Habe den Projekt-Kontext und die Chat-History geladen

Bereit zum Arbeiten! 🚀
```

Dann sind wir startklar!

---

